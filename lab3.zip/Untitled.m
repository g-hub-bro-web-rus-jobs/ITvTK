p=[-0.5 -0.5 +0.3 -0.1; -0.5 +0.5 -0.5 +0.1];
t=[1 1 0 0];
plotpv(p,t);
lab_net = newp([-1 1;-1 1], 1);
e = 1;
lab_net = init (lab_net);
while (sse(e))
    [lab_net, y, e] = adapt (lab_net, p, t);
    drawnow;
end;
plotpc(lab_net.IW{1}, lab_net.b{1});