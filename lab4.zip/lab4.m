P = [1 2 3 4 5];
T = [1 3 5 7 9];
lab_net = newlind(P,T);
y = sim(lab_net,P);
gensim(lab_net, -1);